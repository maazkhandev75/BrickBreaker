////LICENSED PRODUCT BY MAAZ KHAN////

How to run : 

=> There's a file named "Final game.exe". Just run it and the game will start.
=> If The executive file Doesn't Work, Just Copy The .cpp File in A New Visual Studio Project and don't forget to
 include the header file also provided.



About Our Game:

THIS A BRICK SMASHER GAME IN WHICH YOU HAVE TO BREAK BRICKS AND FOR THAT YOU ARE AWARDED SCORE..

~ (YOURGRAPHICS.H) library have been used  to add graphics in this game
~ ALL COMMENTS HAVE BEEN ADDED IN THE SOURCE CODE NAMING FINAL GAME....
~ There is A grid of 5*10 Bricks On the Screen.
~ Total three angles have been formed -45,90,45..
~ A Ball Is Used To Smash The Bricks.
~ A Paddle Is Used To Deflect The Ball In Different 
~ Each Time The Ball Misses The Paddle, One Life Is Lost.
~ If All 3 lives are lost, The Players Loses And A 'GAME OVER' Message Pops Up. 
~ In Order To Win The Game, Destroy All The Bricks.
~ A  'GAME WON', 'GAME OVER' and 'GAME QUITTED' Message Pops Up Everytime The Player Either Wins, Loses or Quits The Game.


Controls:-

--> Press 'a' or 'd' To Move the Paddle 'Left' or 'Right'.
--> Press 'p' To Pause The Game.
--> Press 's' To Save The Game.
--> Press 'esc' To Quit The Game. 
--> Press 'l' for load game.
-->
          

            ------HOPE YOU ENJOY THE GAME------